﻿Public Class frmGameEnd
    Public Sub InsertGameData(win As String, gamet As Integer, mvs As Integer, wmvs As Integer, bmvs As Integer, pcl As Integer, wpcl As Integer, bpcl As Integer)
        GameDataTableAdapter.Insert(win, DateTime.Now, gamet, mvs, wmvs, bmvs, pcl, wpcl, bpcl)
        GameDataTableAdapter.Fill(Me.ScoreKeepDataSet.GameData)
    End Sub

    Private Sub GameDataBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles GameDataBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.GameDataBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.ScoreKeepDataSet)
    End Sub

    Private Sub btn_Replay_Click(sender As Object, e As EventArgs) Handles btn_Replay.Click
        frmMain.TableSet()
        frmMain.Pic_Enable()
        frmMain.btn_Replay.Visible = False
        Close()
    End Sub

    Private Sub btn_Exit_Click(sender As Object, e As EventArgs) Handles btn_Exit.Click
        Close()
    End Sub
End Class