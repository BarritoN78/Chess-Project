﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.btn_Exit = New System.Windows.Forms.Button()
        Me.lbl_Date = New System.Windows.Forms.Label()
        Me.lbl_Time = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.pic_1 = New System.Windows.Forms.PictureBox()
        Me.pic_2 = New System.Windows.Forms.PictureBox()
        Me.pic_3 = New System.Windows.Forms.PictureBox()
        Me.pic_4 = New System.Windows.Forms.PictureBox()
        Me.pic_8 = New System.Windows.Forms.PictureBox()
        Me.pic_7 = New System.Windows.Forms.PictureBox()
        Me.pic_6 = New System.Windows.Forms.PictureBox()
        Me.pic_5 = New System.Windows.Forms.PictureBox()
        Me.pic_12 = New System.Windows.Forms.PictureBox()
        Me.pic_11 = New System.Windows.Forms.PictureBox()
        Me.pic_10 = New System.Windows.Forms.PictureBox()
        Me.pic_9 = New System.Windows.Forms.PictureBox()
        Me.pic_16 = New System.Windows.Forms.PictureBox()
        Me.pic_15 = New System.Windows.Forms.PictureBox()
        Me.pic_14 = New System.Windows.Forms.PictureBox()
        Me.pic_13 = New System.Windows.Forms.PictureBox()
        Me.pic_20 = New System.Windows.Forms.PictureBox()
        Me.pic_19 = New System.Windows.Forms.PictureBox()
        Me.pic_18 = New System.Windows.Forms.PictureBox()
        Me.pic_17 = New System.Windows.Forms.PictureBox()
        Me.pic_24 = New System.Windows.Forms.PictureBox()
        Me.pic_23 = New System.Windows.Forms.PictureBox()
        Me.pic_22 = New System.Windows.Forms.PictureBox()
        Me.pic_21 = New System.Windows.Forms.PictureBox()
        Me.pic_28 = New System.Windows.Forms.PictureBox()
        Me.pic_27 = New System.Windows.Forms.PictureBox()
        Me.pic_26 = New System.Windows.Forms.PictureBox()
        Me.pic_25 = New System.Windows.Forms.PictureBox()
        Me.pic_32 = New System.Windows.Forms.PictureBox()
        Me.pic_31 = New System.Windows.Forms.PictureBox()
        Me.pic_30 = New System.Windows.Forms.PictureBox()
        Me.pic_29 = New System.Windows.Forms.PictureBox()
        Me.pic_36 = New System.Windows.Forms.PictureBox()
        Me.pic_35 = New System.Windows.Forms.PictureBox()
        Me.pic_34 = New System.Windows.Forms.PictureBox()
        Me.pic_33 = New System.Windows.Forms.PictureBox()
        Me.pic_40 = New System.Windows.Forms.PictureBox()
        Me.pic_39 = New System.Windows.Forms.PictureBox()
        Me.pic_38 = New System.Windows.Forms.PictureBox()
        Me.pic_37 = New System.Windows.Forms.PictureBox()
        Me.pic_44 = New System.Windows.Forms.PictureBox()
        Me.pic_43 = New System.Windows.Forms.PictureBox()
        Me.pic_42 = New System.Windows.Forms.PictureBox()
        Me.pic_41 = New System.Windows.Forms.PictureBox()
        Me.pic_48 = New System.Windows.Forms.PictureBox()
        Me.pic_47 = New System.Windows.Forms.PictureBox()
        Me.pic_46 = New System.Windows.Forms.PictureBox()
        Me.pic_45 = New System.Windows.Forms.PictureBox()
        Me.pic_52 = New System.Windows.Forms.PictureBox()
        Me.pic_51 = New System.Windows.Forms.PictureBox()
        Me.pic_50 = New System.Windows.Forms.PictureBox()
        Me.pic_49 = New System.Windows.Forms.PictureBox()
        Me.pic_56 = New System.Windows.Forms.PictureBox()
        Me.pic_55 = New System.Windows.Forms.PictureBox()
        Me.pic_54 = New System.Windows.Forms.PictureBox()
        Me.pic_53 = New System.Windows.Forms.PictureBox()
        Me.pic_60 = New System.Windows.Forms.PictureBox()
        Me.pic_59 = New System.Windows.Forms.PictureBox()
        Me.pic_58 = New System.Windows.Forms.PictureBox()
        Me.pic_57 = New System.Windows.Forms.PictureBox()
        Me.pic_64 = New System.Windows.Forms.PictureBox()
        Me.pic_63 = New System.Windows.Forms.PictureBox()
        Me.pic_62 = New System.Windows.Forms.PictureBox()
        Me.pic_61 = New System.Windows.Forms.PictureBox()
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.btn_Replay = New System.Windows.Forms.Button()
        CType(Me.pic_1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_23, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_21, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_28, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_27, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_31, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_30, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_40, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_39, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_38, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_37, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_41, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_48, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_47, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_51, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_50, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_49, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_60, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_59, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_58, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_57, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic_61, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btn_Exit
        '
        Me.btn_Exit.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Exit.Location = New System.Drawing.Point(432, 389)
        Me.btn_Exit.Name = "btn_Exit"
        Me.btn_Exit.Size = New System.Drawing.Size(75, 23)
        Me.btn_Exit.TabIndex = 0
        Me.btn_Exit.Text = "E&xit"
        Me.btn_Exit.UseVisualStyleBackColor = True
        '
        'lbl_Date
        '
        Me.lbl_Date.AutoSize = True
        Me.lbl_Date.Location = New System.Drawing.Point(429, 13)
        Me.lbl_Date.Name = "lbl_Date"
        Me.lbl_Date.Size = New System.Drawing.Size(32, 15)
        Me.lbl_Date.TabIndex = 1
        Me.lbl_Date.Text = "Date"
        '
        'lbl_Time
        '
        Me.lbl_Time.AutoSize = True
        Me.lbl_Time.Location = New System.Drawing.Point(429, 28)
        Me.lbl_Time.Name = "lbl_Time"
        Me.lbl_Time.Size = New System.Drawing.Size(35, 15)
        Me.lbl_Time.TabIndex = 2
        Me.lbl_Time.Text = "Time"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'pic_1
        '
        Me.pic_1.Image = CType(resources.GetObject("pic_1.Image"), System.Drawing.Image)
        Me.pic_1.Location = New System.Drawing.Point(13, 13)
        Me.pic_1.Name = "pic_1"
        Me.pic_1.Size = New System.Drawing.Size(50, 50)
        Me.pic_1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_1.TabIndex = 3
        Me.pic_1.TabStop = False
        '
        'pic_2
        '
        Me.pic_2.Image = CType(resources.GetObject("pic_2.Image"), System.Drawing.Image)
        Me.pic_2.Location = New System.Drawing.Point(63, 13)
        Me.pic_2.Name = "pic_2"
        Me.pic_2.Size = New System.Drawing.Size(50, 50)
        Me.pic_2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_2.TabIndex = 4
        Me.pic_2.TabStop = False
        '
        'pic_3
        '
        Me.pic_3.Image = CType(resources.GetObject("pic_3.Image"), System.Drawing.Image)
        Me.pic_3.Location = New System.Drawing.Point(113, 13)
        Me.pic_3.Name = "pic_3"
        Me.pic_3.Size = New System.Drawing.Size(50, 50)
        Me.pic_3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_3.TabIndex = 5
        Me.pic_3.TabStop = False
        '
        'pic_4
        '
        Me.pic_4.Image = CType(resources.GetObject("pic_4.Image"), System.Drawing.Image)
        Me.pic_4.Location = New System.Drawing.Point(163, 13)
        Me.pic_4.Name = "pic_4"
        Me.pic_4.Size = New System.Drawing.Size(50, 50)
        Me.pic_4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_4.TabIndex = 6
        Me.pic_4.TabStop = False
        '
        'pic_8
        '
        Me.pic_8.Image = CType(resources.GetObject("pic_8.Image"), System.Drawing.Image)
        Me.pic_8.Location = New System.Drawing.Point(363, 13)
        Me.pic_8.Name = "pic_8"
        Me.pic_8.Size = New System.Drawing.Size(50, 50)
        Me.pic_8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_8.TabIndex = 10
        Me.pic_8.TabStop = False
        '
        'pic_7
        '
        Me.pic_7.Image = CType(resources.GetObject("pic_7.Image"), System.Drawing.Image)
        Me.pic_7.Location = New System.Drawing.Point(313, 13)
        Me.pic_7.Name = "pic_7"
        Me.pic_7.Size = New System.Drawing.Size(50, 50)
        Me.pic_7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_7.TabIndex = 9
        Me.pic_7.TabStop = False
        '
        'pic_6
        '
        Me.pic_6.Image = CType(resources.GetObject("pic_6.Image"), System.Drawing.Image)
        Me.pic_6.Location = New System.Drawing.Point(263, 13)
        Me.pic_6.Name = "pic_6"
        Me.pic_6.Size = New System.Drawing.Size(50, 50)
        Me.pic_6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_6.TabIndex = 8
        Me.pic_6.TabStop = False
        '
        'pic_5
        '
        Me.pic_5.Image = CType(resources.GetObject("pic_5.Image"), System.Drawing.Image)
        Me.pic_5.Location = New System.Drawing.Point(213, 13)
        Me.pic_5.Name = "pic_5"
        Me.pic_5.Size = New System.Drawing.Size(50, 50)
        Me.pic_5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_5.TabIndex = 7
        Me.pic_5.TabStop = False
        '
        'pic_12
        '
        Me.pic_12.Image = CType(resources.GetObject("pic_12.Image"), System.Drawing.Image)
        Me.pic_12.Location = New System.Drawing.Point(163, 63)
        Me.pic_12.Name = "pic_12"
        Me.pic_12.Size = New System.Drawing.Size(50, 50)
        Me.pic_12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_12.TabIndex = 14
        Me.pic_12.TabStop = False
        '
        'pic_11
        '
        Me.pic_11.Image = CType(resources.GetObject("pic_11.Image"), System.Drawing.Image)
        Me.pic_11.Location = New System.Drawing.Point(113, 63)
        Me.pic_11.Name = "pic_11"
        Me.pic_11.Size = New System.Drawing.Size(50, 50)
        Me.pic_11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_11.TabIndex = 13
        Me.pic_11.TabStop = False
        '
        'pic_10
        '
        Me.pic_10.Image = CType(resources.GetObject("pic_10.Image"), System.Drawing.Image)
        Me.pic_10.Location = New System.Drawing.Point(63, 63)
        Me.pic_10.Name = "pic_10"
        Me.pic_10.Size = New System.Drawing.Size(50, 50)
        Me.pic_10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_10.TabIndex = 12
        Me.pic_10.TabStop = False
        '
        'pic_9
        '
        Me.pic_9.Image = CType(resources.GetObject("pic_9.Image"), System.Drawing.Image)
        Me.pic_9.Location = New System.Drawing.Point(13, 63)
        Me.pic_9.Name = "pic_9"
        Me.pic_9.Size = New System.Drawing.Size(50, 50)
        Me.pic_9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_9.TabIndex = 11
        Me.pic_9.TabStop = False
        '
        'pic_16
        '
        Me.pic_16.Image = CType(resources.GetObject("pic_16.Image"), System.Drawing.Image)
        Me.pic_16.Location = New System.Drawing.Point(363, 63)
        Me.pic_16.Name = "pic_16"
        Me.pic_16.Size = New System.Drawing.Size(50, 50)
        Me.pic_16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_16.TabIndex = 18
        Me.pic_16.TabStop = False
        '
        'pic_15
        '
        Me.pic_15.Image = CType(resources.GetObject("pic_15.Image"), System.Drawing.Image)
        Me.pic_15.Location = New System.Drawing.Point(313, 63)
        Me.pic_15.Name = "pic_15"
        Me.pic_15.Size = New System.Drawing.Size(50, 50)
        Me.pic_15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_15.TabIndex = 17
        Me.pic_15.TabStop = False
        '
        'pic_14
        '
        Me.pic_14.Image = CType(resources.GetObject("pic_14.Image"), System.Drawing.Image)
        Me.pic_14.Location = New System.Drawing.Point(263, 63)
        Me.pic_14.Name = "pic_14"
        Me.pic_14.Size = New System.Drawing.Size(50, 50)
        Me.pic_14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_14.TabIndex = 16
        Me.pic_14.TabStop = False
        '
        'pic_13
        '
        Me.pic_13.Image = CType(resources.GetObject("pic_13.Image"), System.Drawing.Image)
        Me.pic_13.Location = New System.Drawing.Point(213, 63)
        Me.pic_13.Name = "pic_13"
        Me.pic_13.Size = New System.Drawing.Size(50, 50)
        Me.pic_13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_13.TabIndex = 15
        Me.pic_13.TabStop = False
        '
        'pic_20
        '
        Me.pic_20.Image = CType(resources.GetObject("pic_20.Image"), System.Drawing.Image)
        Me.pic_20.Location = New System.Drawing.Point(163, 113)
        Me.pic_20.Name = "pic_20"
        Me.pic_20.Size = New System.Drawing.Size(50, 50)
        Me.pic_20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_20.TabIndex = 22
        Me.pic_20.TabStop = False
        '
        'pic_19
        '
        Me.pic_19.Image = CType(resources.GetObject("pic_19.Image"), System.Drawing.Image)
        Me.pic_19.Location = New System.Drawing.Point(113, 113)
        Me.pic_19.Name = "pic_19"
        Me.pic_19.Size = New System.Drawing.Size(50, 50)
        Me.pic_19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_19.TabIndex = 21
        Me.pic_19.TabStop = False
        '
        'pic_18
        '
        Me.pic_18.Image = CType(resources.GetObject("pic_18.Image"), System.Drawing.Image)
        Me.pic_18.Location = New System.Drawing.Point(63, 113)
        Me.pic_18.Name = "pic_18"
        Me.pic_18.Size = New System.Drawing.Size(50, 50)
        Me.pic_18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_18.TabIndex = 20
        Me.pic_18.TabStop = False
        '
        'pic_17
        '
        Me.pic_17.Image = CType(resources.GetObject("pic_17.Image"), System.Drawing.Image)
        Me.pic_17.Location = New System.Drawing.Point(13, 113)
        Me.pic_17.Name = "pic_17"
        Me.pic_17.Size = New System.Drawing.Size(50, 50)
        Me.pic_17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_17.TabIndex = 19
        Me.pic_17.TabStop = False
        '
        'pic_24
        '
        Me.pic_24.Image = CType(resources.GetObject("pic_24.Image"), System.Drawing.Image)
        Me.pic_24.Location = New System.Drawing.Point(363, 113)
        Me.pic_24.Name = "pic_24"
        Me.pic_24.Size = New System.Drawing.Size(50, 50)
        Me.pic_24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_24.TabIndex = 26
        Me.pic_24.TabStop = False
        '
        'pic_23
        '
        Me.pic_23.Image = CType(resources.GetObject("pic_23.Image"), System.Drawing.Image)
        Me.pic_23.Location = New System.Drawing.Point(313, 113)
        Me.pic_23.Name = "pic_23"
        Me.pic_23.Size = New System.Drawing.Size(50, 50)
        Me.pic_23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_23.TabIndex = 25
        Me.pic_23.TabStop = False
        '
        'pic_22
        '
        Me.pic_22.Image = CType(resources.GetObject("pic_22.Image"), System.Drawing.Image)
        Me.pic_22.Location = New System.Drawing.Point(263, 113)
        Me.pic_22.Name = "pic_22"
        Me.pic_22.Size = New System.Drawing.Size(50, 50)
        Me.pic_22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_22.TabIndex = 24
        Me.pic_22.TabStop = False
        '
        'pic_21
        '
        Me.pic_21.Image = CType(resources.GetObject("pic_21.Image"), System.Drawing.Image)
        Me.pic_21.Location = New System.Drawing.Point(213, 113)
        Me.pic_21.Name = "pic_21"
        Me.pic_21.Size = New System.Drawing.Size(50, 50)
        Me.pic_21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_21.TabIndex = 23
        Me.pic_21.TabStop = False
        '
        'pic_28
        '
        Me.pic_28.Image = CType(resources.GetObject("pic_28.Image"), System.Drawing.Image)
        Me.pic_28.Location = New System.Drawing.Point(163, 163)
        Me.pic_28.Name = "pic_28"
        Me.pic_28.Size = New System.Drawing.Size(50, 50)
        Me.pic_28.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_28.TabIndex = 30
        Me.pic_28.TabStop = False
        '
        'pic_27
        '
        Me.pic_27.Image = CType(resources.GetObject("pic_27.Image"), System.Drawing.Image)
        Me.pic_27.Location = New System.Drawing.Point(113, 163)
        Me.pic_27.Name = "pic_27"
        Me.pic_27.Size = New System.Drawing.Size(50, 50)
        Me.pic_27.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_27.TabIndex = 29
        Me.pic_27.TabStop = False
        '
        'pic_26
        '
        Me.pic_26.Image = CType(resources.GetObject("pic_26.Image"), System.Drawing.Image)
        Me.pic_26.Location = New System.Drawing.Point(63, 163)
        Me.pic_26.Name = "pic_26"
        Me.pic_26.Size = New System.Drawing.Size(50, 50)
        Me.pic_26.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_26.TabIndex = 28
        Me.pic_26.TabStop = False
        '
        'pic_25
        '
        Me.pic_25.Image = CType(resources.GetObject("pic_25.Image"), System.Drawing.Image)
        Me.pic_25.Location = New System.Drawing.Point(13, 163)
        Me.pic_25.Name = "pic_25"
        Me.pic_25.Size = New System.Drawing.Size(50, 50)
        Me.pic_25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_25.TabIndex = 27
        Me.pic_25.TabStop = False
        '
        'pic_32
        '
        Me.pic_32.Image = CType(resources.GetObject("pic_32.Image"), System.Drawing.Image)
        Me.pic_32.Location = New System.Drawing.Point(363, 163)
        Me.pic_32.Name = "pic_32"
        Me.pic_32.Size = New System.Drawing.Size(50, 50)
        Me.pic_32.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_32.TabIndex = 34
        Me.pic_32.TabStop = False
        '
        'pic_31
        '
        Me.pic_31.Image = CType(resources.GetObject("pic_31.Image"), System.Drawing.Image)
        Me.pic_31.Location = New System.Drawing.Point(313, 163)
        Me.pic_31.Name = "pic_31"
        Me.pic_31.Size = New System.Drawing.Size(50, 50)
        Me.pic_31.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_31.TabIndex = 33
        Me.pic_31.TabStop = False
        '
        'pic_30
        '
        Me.pic_30.Image = CType(resources.GetObject("pic_30.Image"), System.Drawing.Image)
        Me.pic_30.Location = New System.Drawing.Point(263, 163)
        Me.pic_30.Name = "pic_30"
        Me.pic_30.Size = New System.Drawing.Size(50, 50)
        Me.pic_30.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_30.TabIndex = 32
        Me.pic_30.TabStop = False
        '
        'pic_29
        '
        Me.pic_29.Image = CType(resources.GetObject("pic_29.Image"), System.Drawing.Image)
        Me.pic_29.Location = New System.Drawing.Point(213, 163)
        Me.pic_29.Name = "pic_29"
        Me.pic_29.Size = New System.Drawing.Size(50, 50)
        Me.pic_29.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_29.TabIndex = 31
        Me.pic_29.TabStop = False
        '
        'pic_36
        '
        Me.pic_36.Image = CType(resources.GetObject("pic_36.Image"), System.Drawing.Image)
        Me.pic_36.Location = New System.Drawing.Point(163, 213)
        Me.pic_36.Name = "pic_36"
        Me.pic_36.Size = New System.Drawing.Size(50, 50)
        Me.pic_36.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_36.TabIndex = 38
        Me.pic_36.TabStop = False
        '
        'pic_35
        '
        Me.pic_35.Image = CType(resources.GetObject("pic_35.Image"), System.Drawing.Image)
        Me.pic_35.Location = New System.Drawing.Point(113, 213)
        Me.pic_35.Name = "pic_35"
        Me.pic_35.Size = New System.Drawing.Size(50, 50)
        Me.pic_35.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_35.TabIndex = 37
        Me.pic_35.TabStop = False
        '
        'pic_34
        '
        Me.pic_34.Image = CType(resources.GetObject("pic_34.Image"), System.Drawing.Image)
        Me.pic_34.Location = New System.Drawing.Point(63, 213)
        Me.pic_34.Name = "pic_34"
        Me.pic_34.Size = New System.Drawing.Size(50, 50)
        Me.pic_34.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_34.TabIndex = 36
        Me.pic_34.TabStop = False
        '
        'pic_33
        '
        Me.pic_33.Image = CType(resources.GetObject("pic_33.Image"), System.Drawing.Image)
        Me.pic_33.Location = New System.Drawing.Point(13, 213)
        Me.pic_33.Name = "pic_33"
        Me.pic_33.Size = New System.Drawing.Size(50, 50)
        Me.pic_33.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_33.TabIndex = 35
        Me.pic_33.TabStop = False
        '
        'pic_40
        '
        Me.pic_40.Image = CType(resources.GetObject("pic_40.Image"), System.Drawing.Image)
        Me.pic_40.Location = New System.Drawing.Point(363, 213)
        Me.pic_40.Name = "pic_40"
        Me.pic_40.Size = New System.Drawing.Size(50, 50)
        Me.pic_40.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_40.TabIndex = 42
        Me.pic_40.TabStop = False
        '
        'pic_39
        '
        Me.pic_39.Image = CType(resources.GetObject("pic_39.Image"), System.Drawing.Image)
        Me.pic_39.Location = New System.Drawing.Point(313, 213)
        Me.pic_39.Name = "pic_39"
        Me.pic_39.Size = New System.Drawing.Size(50, 50)
        Me.pic_39.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_39.TabIndex = 41
        Me.pic_39.TabStop = False
        '
        'pic_38
        '
        Me.pic_38.Image = CType(resources.GetObject("pic_38.Image"), System.Drawing.Image)
        Me.pic_38.Location = New System.Drawing.Point(263, 213)
        Me.pic_38.Name = "pic_38"
        Me.pic_38.Size = New System.Drawing.Size(50, 50)
        Me.pic_38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_38.TabIndex = 40
        Me.pic_38.TabStop = False
        '
        'pic_37
        '
        Me.pic_37.Image = CType(resources.GetObject("pic_37.Image"), System.Drawing.Image)
        Me.pic_37.Location = New System.Drawing.Point(213, 213)
        Me.pic_37.Name = "pic_37"
        Me.pic_37.Size = New System.Drawing.Size(50, 50)
        Me.pic_37.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_37.TabIndex = 39
        Me.pic_37.TabStop = False
        '
        'pic_44
        '
        Me.pic_44.Image = CType(resources.GetObject("pic_44.Image"), System.Drawing.Image)
        Me.pic_44.Location = New System.Drawing.Point(163, 263)
        Me.pic_44.Name = "pic_44"
        Me.pic_44.Size = New System.Drawing.Size(50, 50)
        Me.pic_44.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_44.TabIndex = 46
        Me.pic_44.TabStop = False
        '
        'pic_43
        '
        Me.pic_43.Image = CType(resources.GetObject("pic_43.Image"), System.Drawing.Image)
        Me.pic_43.Location = New System.Drawing.Point(113, 263)
        Me.pic_43.Name = "pic_43"
        Me.pic_43.Size = New System.Drawing.Size(50, 50)
        Me.pic_43.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_43.TabIndex = 45
        Me.pic_43.TabStop = False
        '
        'pic_42
        '
        Me.pic_42.Image = CType(resources.GetObject("pic_42.Image"), System.Drawing.Image)
        Me.pic_42.Location = New System.Drawing.Point(63, 263)
        Me.pic_42.Name = "pic_42"
        Me.pic_42.Size = New System.Drawing.Size(50, 50)
        Me.pic_42.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_42.TabIndex = 44
        Me.pic_42.TabStop = False
        '
        'pic_41
        '
        Me.pic_41.Image = CType(resources.GetObject("pic_41.Image"), System.Drawing.Image)
        Me.pic_41.Location = New System.Drawing.Point(13, 263)
        Me.pic_41.Name = "pic_41"
        Me.pic_41.Size = New System.Drawing.Size(50, 50)
        Me.pic_41.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_41.TabIndex = 43
        Me.pic_41.TabStop = False
        '
        'pic_48
        '
        Me.pic_48.Image = CType(resources.GetObject("pic_48.Image"), System.Drawing.Image)
        Me.pic_48.Location = New System.Drawing.Point(363, 263)
        Me.pic_48.Name = "pic_48"
        Me.pic_48.Size = New System.Drawing.Size(50, 50)
        Me.pic_48.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_48.TabIndex = 50
        Me.pic_48.TabStop = False
        '
        'pic_47
        '
        Me.pic_47.Image = CType(resources.GetObject("pic_47.Image"), System.Drawing.Image)
        Me.pic_47.Location = New System.Drawing.Point(313, 263)
        Me.pic_47.Name = "pic_47"
        Me.pic_47.Size = New System.Drawing.Size(50, 50)
        Me.pic_47.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_47.TabIndex = 49
        Me.pic_47.TabStop = False
        '
        'pic_46
        '
        Me.pic_46.Image = CType(resources.GetObject("pic_46.Image"), System.Drawing.Image)
        Me.pic_46.Location = New System.Drawing.Point(263, 263)
        Me.pic_46.Name = "pic_46"
        Me.pic_46.Size = New System.Drawing.Size(50, 50)
        Me.pic_46.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_46.TabIndex = 48
        Me.pic_46.TabStop = False
        '
        'pic_45
        '
        Me.pic_45.Image = CType(resources.GetObject("pic_45.Image"), System.Drawing.Image)
        Me.pic_45.Location = New System.Drawing.Point(213, 263)
        Me.pic_45.Name = "pic_45"
        Me.pic_45.Size = New System.Drawing.Size(50, 50)
        Me.pic_45.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_45.TabIndex = 47
        Me.pic_45.TabStop = False
        '
        'pic_52
        '
        Me.pic_52.Image = CType(resources.GetObject("pic_52.Image"), System.Drawing.Image)
        Me.pic_52.Location = New System.Drawing.Point(163, 313)
        Me.pic_52.Name = "pic_52"
        Me.pic_52.Size = New System.Drawing.Size(50, 50)
        Me.pic_52.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_52.TabIndex = 54
        Me.pic_52.TabStop = False
        '
        'pic_51
        '
        Me.pic_51.Image = CType(resources.GetObject("pic_51.Image"), System.Drawing.Image)
        Me.pic_51.Location = New System.Drawing.Point(113, 313)
        Me.pic_51.Name = "pic_51"
        Me.pic_51.Size = New System.Drawing.Size(50, 50)
        Me.pic_51.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_51.TabIndex = 53
        Me.pic_51.TabStop = False
        '
        'pic_50
        '
        Me.pic_50.Image = CType(resources.GetObject("pic_50.Image"), System.Drawing.Image)
        Me.pic_50.Location = New System.Drawing.Point(63, 313)
        Me.pic_50.Name = "pic_50"
        Me.pic_50.Size = New System.Drawing.Size(50, 50)
        Me.pic_50.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_50.TabIndex = 52
        Me.pic_50.TabStop = False
        '
        'pic_49
        '
        Me.pic_49.Image = CType(resources.GetObject("pic_49.Image"), System.Drawing.Image)
        Me.pic_49.Location = New System.Drawing.Point(13, 313)
        Me.pic_49.Name = "pic_49"
        Me.pic_49.Size = New System.Drawing.Size(50, 50)
        Me.pic_49.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_49.TabIndex = 51
        Me.pic_49.TabStop = False
        '
        'pic_56
        '
        Me.pic_56.Image = CType(resources.GetObject("pic_56.Image"), System.Drawing.Image)
        Me.pic_56.Location = New System.Drawing.Point(363, 313)
        Me.pic_56.Name = "pic_56"
        Me.pic_56.Size = New System.Drawing.Size(50, 50)
        Me.pic_56.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_56.TabIndex = 58
        Me.pic_56.TabStop = False
        '
        'pic_55
        '
        Me.pic_55.Image = CType(resources.GetObject("pic_55.Image"), System.Drawing.Image)
        Me.pic_55.Location = New System.Drawing.Point(313, 313)
        Me.pic_55.Name = "pic_55"
        Me.pic_55.Size = New System.Drawing.Size(50, 50)
        Me.pic_55.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_55.TabIndex = 57
        Me.pic_55.TabStop = False
        '
        'pic_54
        '
        Me.pic_54.Image = CType(resources.GetObject("pic_54.Image"), System.Drawing.Image)
        Me.pic_54.Location = New System.Drawing.Point(263, 313)
        Me.pic_54.Name = "pic_54"
        Me.pic_54.Size = New System.Drawing.Size(50, 50)
        Me.pic_54.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_54.TabIndex = 56
        Me.pic_54.TabStop = False
        '
        'pic_53
        '
        Me.pic_53.Image = CType(resources.GetObject("pic_53.Image"), System.Drawing.Image)
        Me.pic_53.Location = New System.Drawing.Point(213, 313)
        Me.pic_53.Name = "pic_53"
        Me.pic_53.Size = New System.Drawing.Size(50, 50)
        Me.pic_53.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_53.TabIndex = 55
        Me.pic_53.TabStop = False
        '
        'pic_60
        '
        Me.pic_60.Image = CType(resources.GetObject("pic_60.Image"), System.Drawing.Image)
        Me.pic_60.Location = New System.Drawing.Point(163, 363)
        Me.pic_60.Name = "pic_60"
        Me.pic_60.Size = New System.Drawing.Size(50, 50)
        Me.pic_60.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_60.TabIndex = 62
        Me.pic_60.TabStop = False
        '
        'pic_59
        '
        Me.pic_59.Image = CType(resources.GetObject("pic_59.Image"), System.Drawing.Image)
        Me.pic_59.Location = New System.Drawing.Point(113, 363)
        Me.pic_59.Name = "pic_59"
        Me.pic_59.Size = New System.Drawing.Size(50, 50)
        Me.pic_59.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_59.TabIndex = 61
        Me.pic_59.TabStop = False
        '
        'pic_58
        '
        Me.pic_58.Image = CType(resources.GetObject("pic_58.Image"), System.Drawing.Image)
        Me.pic_58.Location = New System.Drawing.Point(63, 363)
        Me.pic_58.Name = "pic_58"
        Me.pic_58.Size = New System.Drawing.Size(50, 50)
        Me.pic_58.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_58.TabIndex = 60
        Me.pic_58.TabStop = False
        '
        'pic_57
        '
        Me.pic_57.Image = CType(resources.GetObject("pic_57.Image"), System.Drawing.Image)
        Me.pic_57.Location = New System.Drawing.Point(13, 363)
        Me.pic_57.Name = "pic_57"
        Me.pic_57.Size = New System.Drawing.Size(50, 50)
        Me.pic_57.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_57.TabIndex = 59
        Me.pic_57.TabStop = False
        '
        'pic_64
        '
        Me.pic_64.Image = CType(resources.GetObject("pic_64.Image"), System.Drawing.Image)
        Me.pic_64.Location = New System.Drawing.Point(363, 363)
        Me.pic_64.Name = "pic_64"
        Me.pic_64.Size = New System.Drawing.Size(50, 50)
        Me.pic_64.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_64.TabIndex = 66
        Me.pic_64.TabStop = False
        '
        'pic_63
        '
        Me.pic_63.Image = CType(resources.GetObject("pic_63.Image"), System.Drawing.Image)
        Me.pic_63.Location = New System.Drawing.Point(313, 363)
        Me.pic_63.Name = "pic_63"
        Me.pic_63.Size = New System.Drawing.Size(50, 50)
        Me.pic_63.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_63.TabIndex = 65
        Me.pic_63.TabStop = False
        '
        'pic_62
        '
        Me.pic_62.Image = CType(resources.GetObject("pic_62.Image"), System.Drawing.Image)
        Me.pic_62.Location = New System.Drawing.Point(263, 363)
        Me.pic_62.Name = "pic_62"
        Me.pic_62.Size = New System.Drawing.Size(50, 50)
        Me.pic_62.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_62.TabIndex = 64
        Me.pic_62.TabStop = False
        '
        'pic_61
        '
        Me.pic_61.Image = CType(resources.GetObject("pic_61.Image"), System.Drawing.Image)
        Me.pic_61.Location = New System.Drawing.Point(213, 363)
        Me.pic_61.Name = "pic_61"
        Me.pic_61.Size = New System.Drawing.Size(50, 50)
        Me.pic_61.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic_61.TabIndex = 63
        Me.pic_61.TabStop = False
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        Me.Timer2.Interval = 1000
        '
        'btn_Replay
        '
        Me.btn_Replay.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btn_Replay.Location = New System.Drawing.Point(432, 360)
        Me.btn_Replay.Name = "btn_Replay"
        Me.btn_Replay.Size = New System.Drawing.Size(75, 23)
        Me.btn_Replay.TabIndex = 67
        Me.btn_Replay.Text = "&Replay"
        Me.btn_Replay.UseVisualStyleBackColor = True
        Me.btn_Replay.Visible = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.CancelButton = Me.btn_Exit
        Me.ClientSize = New System.Drawing.Size(630, 424)
        Me.Controls.Add(Me.btn_Replay)
        Me.Controls.Add(Me.pic_64)
        Me.Controls.Add(Me.pic_63)
        Me.Controls.Add(Me.pic_62)
        Me.Controls.Add(Me.pic_61)
        Me.Controls.Add(Me.pic_60)
        Me.Controls.Add(Me.pic_59)
        Me.Controls.Add(Me.pic_58)
        Me.Controls.Add(Me.pic_57)
        Me.Controls.Add(Me.pic_56)
        Me.Controls.Add(Me.pic_55)
        Me.Controls.Add(Me.pic_54)
        Me.Controls.Add(Me.pic_53)
        Me.Controls.Add(Me.pic_52)
        Me.Controls.Add(Me.pic_51)
        Me.Controls.Add(Me.pic_50)
        Me.Controls.Add(Me.pic_49)
        Me.Controls.Add(Me.pic_48)
        Me.Controls.Add(Me.pic_47)
        Me.Controls.Add(Me.pic_46)
        Me.Controls.Add(Me.pic_45)
        Me.Controls.Add(Me.pic_44)
        Me.Controls.Add(Me.pic_43)
        Me.Controls.Add(Me.pic_42)
        Me.Controls.Add(Me.pic_41)
        Me.Controls.Add(Me.pic_40)
        Me.Controls.Add(Me.pic_39)
        Me.Controls.Add(Me.pic_38)
        Me.Controls.Add(Me.pic_37)
        Me.Controls.Add(Me.pic_36)
        Me.Controls.Add(Me.pic_35)
        Me.Controls.Add(Me.pic_34)
        Me.Controls.Add(Me.pic_33)
        Me.Controls.Add(Me.pic_32)
        Me.Controls.Add(Me.pic_31)
        Me.Controls.Add(Me.pic_30)
        Me.Controls.Add(Me.pic_29)
        Me.Controls.Add(Me.pic_28)
        Me.Controls.Add(Me.pic_27)
        Me.Controls.Add(Me.pic_26)
        Me.Controls.Add(Me.pic_25)
        Me.Controls.Add(Me.pic_24)
        Me.Controls.Add(Me.pic_23)
        Me.Controls.Add(Me.pic_22)
        Me.Controls.Add(Me.pic_21)
        Me.Controls.Add(Me.pic_20)
        Me.Controls.Add(Me.pic_19)
        Me.Controls.Add(Me.pic_18)
        Me.Controls.Add(Me.pic_17)
        Me.Controls.Add(Me.pic_16)
        Me.Controls.Add(Me.pic_15)
        Me.Controls.Add(Me.pic_14)
        Me.Controls.Add(Me.pic_13)
        Me.Controls.Add(Me.pic_12)
        Me.Controls.Add(Me.pic_11)
        Me.Controls.Add(Me.pic_10)
        Me.Controls.Add(Me.pic_9)
        Me.Controls.Add(Me.pic_8)
        Me.Controls.Add(Me.pic_7)
        Me.Controls.Add(Me.pic_6)
        Me.Controls.Add(Me.pic_5)
        Me.Controls.Add(Me.pic_4)
        Me.Controls.Add(Me.pic_3)
        Me.Controls.Add(Me.pic_2)
        Me.Controls.Add(Me.pic_1)
        Me.Controls.Add(Me.lbl_Time)
        Me.Controls.Add(Me.lbl_Date)
        Me.Controls.Add(Me.btn_Exit)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Barry-Norton-Final-Project"
        CType(Me.pic_1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_23, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_21, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_28, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_27, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_31, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_30, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_40, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_39, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_38, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_37, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_41, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_48, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_47, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_51, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_50, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_49, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_60, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_59, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_58, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_57, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic_61, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip1 As ToolTip
    Friend WithEvents btn_Exit As Button
    Friend WithEvents lbl_Date As Label
    Friend WithEvents lbl_Time As Label
    Friend WithEvents Timer1 As Timer
    Friend WithEvents pic_1 As PictureBox
    Friend WithEvents pic_2 As PictureBox
    Friend WithEvents pic_3 As PictureBox
    Friend WithEvents pic_4 As PictureBox
    Friend WithEvents pic_8 As PictureBox
    Friend WithEvents pic_7 As PictureBox
    Friend WithEvents pic_6 As PictureBox
    Friend WithEvents pic_5 As PictureBox
    Friend WithEvents pic_12 As PictureBox
    Friend WithEvents pic_11 As PictureBox
    Friend WithEvents pic_10 As PictureBox
    Friend WithEvents pic_9 As PictureBox
    Friend WithEvents pic_16 As PictureBox
    Friend WithEvents pic_15 As PictureBox
    Friend WithEvents pic_14 As PictureBox
    Friend WithEvents pic_13 As PictureBox
    Friend WithEvents pic_20 As PictureBox
    Friend WithEvents pic_19 As PictureBox
    Friend WithEvents pic_18 As PictureBox
    Friend WithEvents pic_17 As PictureBox
    Friend WithEvents pic_24 As PictureBox
    Friend WithEvents pic_23 As PictureBox
    Friend WithEvents pic_22 As PictureBox
    Friend WithEvents pic_21 As PictureBox
    Friend WithEvents pic_28 As PictureBox
    Friend WithEvents pic_27 As PictureBox
    Friend WithEvents pic_26 As PictureBox
    Friend WithEvents pic_25 As PictureBox
    Friend WithEvents pic_32 As PictureBox
    Friend WithEvents pic_31 As PictureBox
    Friend WithEvents pic_30 As PictureBox
    Friend WithEvents pic_29 As PictureBox
    Friend WithEvents pic_36 As PictureBox
    Friend WithEvents pic_35 As PictureBox
    Friend WithEvents pic_34 As PictureBox
    Friend WithEvents pic_33 As PictureBox
    Friend WithEvents pic_40 As PictureBox
    Friend WithEvents pic_39 As PictureBox
    Friend WithEvents pic_38 As PictureBox
    Friend WithEvents pic_37 As PictureBox
    Friend WithEvents pic_44 As PictureBox
    Friend WithEvents pic_43 As PictureBox
    Friend WithEvents pic_42 As PictureBox
    Friend WithEvents pic_41 As PictureBox
    Friend WithEvents pic_48 As PictureBox
    Friend WithEvents pic_47 As PictureBox
    Friend WithEvents pic_46 As PictureBox
    Friend WithEvents pic_45 As PictureBox
    Friend WithEvents pic_52 As PictureBox
    Friend WithEvents pic_51 As PictureBox
    Friend WithEvents pic_50 As PictureBox
    Friend WithEvents pic_49 As PictureBox
    Friend WithEvents pic_56 As PictureBox
    Friend WithEvents pic_55 As PictureBox
    Friend WithEvents pic_54 As PictureBox
    Friend WithEvents pic_53 As PictureBox
    Friend WithEvents pic_60 As PictureBox
    Friend WithEvents pic_59 As PictureBox
    Friend WithEvents pic_58 As PictureBox
    Friend WithEvents pic_57 As PictureBox
    Friend WithEvents pic_64 As PictureBox
    Friend WithEvents pic_63 As PictureBox
    Friend WithEvents pic_62 As PictureBox
    Friend WithEvents pic_61 As PictureBox
    Friend WithEvents Timer2 As Timer
    Friend WithEvents btn_Replay As Button
End Class
